#include "main.h"

// implement function body
void sayHello(char* name) {
    printf("Hello %s\n", name);
}


int main(void) {
    sayHello( (char*) "John");
}