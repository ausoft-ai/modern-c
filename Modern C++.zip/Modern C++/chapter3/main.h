#ifndef MY_HEADER_FILE_H
#define MY_HEADER_FILE_H

#include <stdio.h>

// declare function prototype
void sayHello(char* name);

#endif