   #include <iostream>
   #include <fstream>

   void createFile() {
           std::ofstream outputFile("example.txt");

       if (outputFile.is_open()) {
           // Write data to the file
           outputFile << "Hello World!" << std::endl;

           outputFile.close(); // Close the file
       } else {
           std::cerr << "Unable to create or open the file." << std::endl;

       }
   }

   int main() {
       createFile();

       std::ifstream inputFile("example.txt");
       if (inputFile.is_open()) {
           // Read data from the file
           std::string line;
           while (getline(inputFile, line)) {
               std::cout << line << std::endl;
           }
           inputFile.close(); // Close the file
       } else {
           std::cerr << "Unable to open the file." << std::endl;
       }

       return 0;
   }
