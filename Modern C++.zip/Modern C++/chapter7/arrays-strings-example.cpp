#include <stdio.h>
#include <string>

int intArray[5] = {1,2,3,4,5};
char charArray[10] = "Hello\0";

int main(void) {

    printf("intArray values:\n");
    for (int i = 0; i < 5; i++) {
        printf("position %d value is %d\n", i, intArray[i]);
    }
    printf("\n");

    printf("charArray = %s\n", charArray);
    printf("charArray values:\n");
    for (int i = 0; i < 5; i++) {
        printf("position %d value is %c\n", i, charArray[i]);
    }

    std::string str = "Hello World";
    printf("Convert string to C String = %s\n", str.c_str());
    printf("length of string = %lu\n", str.length());


    return 0;
}