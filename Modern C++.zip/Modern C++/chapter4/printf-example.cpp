#include <cstdio>

int main() {
    // Integer formatting
    int intValue = 42;
    printf("Integer value: %d\n", intValue);

    // Floating-point formatting
    double doubleValue = 3.14159;
    printf("Double value: %f\n", doubleValue);

    // String formatting
    const char* stringValue = "Hello, printf!";
    printf("String value: %s\n", stringValue);

    // Character formatting
    char charValue = 'A';
    printf("Character value: %c\n", charValue);

    // Hexadecimal formatting
    int hexValue = 255;
    printf("Hexadecimal value: %x\n", hexValue);

    // Width and precision
    double precisionValue = 123.456789;
    printf("Precision value: %.2f\n", precisionValue);

    // Field width
    int fieldWidthValue = 12345;
    printf("Field width value: %10d\n", fieldWidthValue);

    // Left justification
    printf("Left-justified value: %-10d\n", fieldWidthValue);

    // Printing multiple values
    int value1 = 10;
    double value2 = 20.5;
    printf("Multiple values: %d and %.2f\n", value1, value2);

    // Printing formatted strings
    const char* formattedString = "Formatted values: %d, %.2f, %s\n";
    printf(formattedString, value1, value2, stringValue);

    return 0;
}
