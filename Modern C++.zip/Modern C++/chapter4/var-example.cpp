#include <stdio.h>

int x = 0; // default x to zero
int y = 0; // default y to zero

int main(void) {

    // display x and y initial values
    printf("Initial : x = %d, y = %d\n", x, y);

    // set value of x to 10
    x = 10;
    // set value of y to x / 2
    y = x / 2;

    // display new values for x and y
    printf("Updated : x = %d, y = %d\n", x, y);

    return 0;

}