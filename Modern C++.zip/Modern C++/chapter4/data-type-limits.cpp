#include <stdio.h>
#include <limits>

int main() {
    printf("Minimum value for double: %f\n", std::numeric_limits<double>::min());
    printf("Maximum value for double: %f\n", std::numeric_limits<double>::max());

    printf("Minimum value for int: %d\n", std::numeric_limits<int>::min());
    printf("Maximum value for int: %d\n", std::numeric_limits<int>::max());

    return 0;
}
