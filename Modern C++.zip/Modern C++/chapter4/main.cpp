#include <stdio.h>
#include <stdlib.h>
#include <string.h>

using namespace std;

int main() {
    // Fundamental Data Types
    int age = 80;
    float height = 5.8;
    char initial = 't';
    bool isRetired = true;

    printf("age=%d, height=%0.2f, initial=%c, isRetired=%d\n",
      age, height, initial, isRetired);

    // Derived Data Types
    int numbers[5] = {1, 2, 3, 4, 5};  // Array
    int* pointerToAge = &age;          // Pointer
    int& referenceToAge = age;         // Reference

    printf("numbers[0]=%d\n", numbers[0]);
    printf("numbers[1]=%d\n", numbers[1]);
    printf("numbers[2]=%d\n", numbers[2]);
    printf("numbers[3]=%d\n", numbers[3]);
    printf("numbers[4]=%d\n", numbers[4]);


    // User-Defined Data Types
    struct Person {
        char name[20];
        int age;
    };

    Person person; // Instance of a structure
    strcpy(person.name,  "Joe");
    person.age = 20;

    printf("Name=%s, Age=%d\n", person.name, person.age);


    return 0;
}
