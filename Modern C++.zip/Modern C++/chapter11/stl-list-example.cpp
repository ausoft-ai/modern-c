#include <iostream>
#include <list>

int main() {
    // Creating a list of integers
    std::list<int> myList;

    // Adding elements to the list
    myList.push_back(1);
    myList.push_back(2);
    myList.push_back(3);

    // Iterating through the list
    for (const auto& element : myList) {
        std::cout << element << " ";
    }
    std::cout << std::endl;

    // Inserting an element in the middle
    auto it = std::next(myList.begin()); // Iterator pointing to the second element
    myList.insert(it, 5);

    // Deleting the first element
    myList.pop_front();

    // Iterating through the modified list
    for (const auto& element : myList) {
        std::cout << element << " ";
    }
    std::cout << std::endl;

    return 0;
}
