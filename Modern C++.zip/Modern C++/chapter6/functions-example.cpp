#include <stdio.h>

// -------------------------------
// Function prototypes
// -------------------------------
int sum(int a, int b);
double sum(double a, double b);
int factorial(int n);
void hello(void);


// -------------------------------
// Function definitions
// -------------------------------
int sum(int a, int b) {
    return a + b;
}

double sum(double a, double b) {
    return a + b;
}

// Recursion with default 10
int factorial(int n = 10) {
    if (n <= 1) {
        return 1;
    }
    else {
        return n * factorial(n - 1);
    }
}

// no parameters and no return type
void hello(void) {
    printf("Hello\n");
}

// -------------------------------
// main
// -------------------------------
int main(void) {
    hello();
    printf("10 + 5 = %d\n", sum(10,5));
    printf("99.99 + 0.01 = %f\n", sum(99.99, 0.01));
    printf("factorial(5) = %d\n", factorial(5));
    printf("factorial() = %d\n", factorial());
}


