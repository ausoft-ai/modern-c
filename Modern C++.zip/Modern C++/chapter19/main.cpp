#include <iostream>

// Define an enumeration named Color
enum Color {
    Red,    // Red   = 0
    Green,  // Green = 1
    Blue    // Blue  = 2
};

int main() {
    // Declare a variable of type Color
    Color myColor;

    // Assign the value of Green to myColor
    myColor = Green;

    // Check the value of myColor and print
    if (myColor == Red) {
        std::cout << "Red." << std::endl;
    } else if (myColor == Green) {
        std::cout << "Green." << std::endl;
    } else if (myColor == Blue) {
        std::cout << "Blue." << std::endl;
    }

    return 0;
}
