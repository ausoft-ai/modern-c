#include <iostream>
#include <thread>
#include <mutex>

std::mutex myMutex;

void sharedResourceFunction(int threadId) {
    std::lock_guard<std::mutex> lock(myMutex);

    // Critical section (shared resource)
    std::cout << "Thread " << threadId << " accessing shared resource." << std::endl;
}

int main() {
    std::thread thread1(sharedResourceFunction, 1);
    std::thread thread2(sharedResourceFunction, 2);

    thread1.join();
    thread2.join();

    return 0;
}
