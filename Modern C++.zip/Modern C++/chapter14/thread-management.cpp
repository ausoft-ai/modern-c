#include <iostream>
#include <thread>
#include <chrono>

void workerFunction() {
    std::this_thread::sleep_for(std::chrono::seconds(2));
    std::cout << "Work done in thread." << std::endl;
}

int main() {
    std::thread workerThread(workerFunction);

    // Wait for the thread to finish
    workerThread.join(); 
    return 0;
}
