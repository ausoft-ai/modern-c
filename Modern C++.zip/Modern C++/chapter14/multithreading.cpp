#include <iostream>
#include <thread>

void myFunction() {
   std::cout << "Hello from thread!" << std::endl;
}

int main() {
       std::thread myThread(myFunction);

       // Do some work in the main thread
       for (int i = 0; i < 10; i++) {
          std::cout << "main thread - " << i << std::endl;
       }

       // Wait for the thread to finish
       myThread.join();  

       return 0;
   }
