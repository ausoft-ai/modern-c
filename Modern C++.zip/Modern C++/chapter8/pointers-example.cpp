#include <iostream>
#include <memory>

struct Car {
    std::string model;
    std::string make;
    int year;
};

void updateYear(Car *car, int year) {
    car->year = year;
}

void updateModel(std::string & model, std::string newModel) {
    model = newModel;
}


int main(void) {

    // pointer with manual memory management
    Car *myCar = new Car();

    myCar->make = "Toyota";
    myCar->model = "Hilux";
    myCar->year = 2020;

    std::cout << "My Car:" << std::endl;
    std::cout << "- Make  : " << myCar->make << std::endl;
    std::cout << "- Model : " << myCar->model << std::endl;
    std::cout << "- Year  : " << myCar->year << std::endl;

    delete myCar;

    // pointer example using smart pointers to manage the memory for us
    std::unique_ptr<Car> yourCar(new Car());
    yourCar->make = "VW";
    yourCar->model = "Jetta";
    yourCar->year = 2000;

    std::cout << "your Car:" << std::endl;
    std::cout << "- Make  : " << yourCar->make << std::endl;
    std::cout << "- Model : " << yourCar->model << std::endl;
    std::cout << "- Year  : " << yourCar->year << std::endl;

    // not using pointers but references
    // notice that we are using . and not -> after newCar since we are not using a pointer
    Car newCar;
    newCar.make = "BMW";
    newCar.model = "X5";
    newCar.year = 2024;

    updateYear(&newCar, 2025); // pointer to newCar using & symbol
    updateModel(newCar.model, "i7"); // directly updating newCar.model to "i7"

    std::cout << "New Car:" << std::endl;
    std::cout << "- Make  : " << newCar.make << std::endl;
    std::cout << "- Model : " << newCar.model << std::endl;
    std::cout << "- Year  : " << newCar.year << std::endl;

    return 0;
}