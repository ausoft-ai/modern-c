#include <iostream>

   void divide(int numerator, int denominator) {
       if (denominator == 0) {
           throw std::runtime_error("Division by zero is not allowed.");
       }
       int result = numerator / denominator;
       std::cout << "Result: " << result << std::endl;
   }

   int main() {
       try {
           // okay
           divide(10, 2);
           // Throws and exception
           divide(5, 0); 
           // skipped if an exception occurs in the previous line
           divide(8, 4);
       } catch (const std::exception& e) {
           std::cerr << "Exception caught: " << e.what() << std::endl;
       }

       return 0;
   }
