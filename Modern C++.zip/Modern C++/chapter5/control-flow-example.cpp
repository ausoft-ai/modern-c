#include <stdio.h>


int main(void) {

    // sequential execution
    int a = 10;
    int b = 20;
    int x = a + b;


    // conditional statements
    if (x > 30) {
        printf("x is greater than 30\n");
    } else {
        printf("x is equal or smaller than 30\n");
    }

    switch (x) {
        case 30: printf("x equals 30\n");
        break;

        default: printf("x is not equal to 30\n");
    }


    // for loop
    printf("Counting to %d\n", a);
    for (int i = 1; i <= a; i++) {
        printf("%d ", i);
    }
    printf("\n");

    // while loop
    printf("Counting backwards from %d\n", a);
    while (a > 0) {
        printf("%d ", a);
        a--;
    }
    printf("\n");

    // do-while loop
    do {
        printf("The value of b is : %d\n", b++);

    } while (b < 22);

    // return
    return 0;

}