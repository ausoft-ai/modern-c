#include <iostream>


class Vehicle {

    protected:
        int wheels;
        int doors;
        std::string registration;
        std::string color;

    public:
        // setters
        void setWheels(int value) {
            wheels = value;
        }
        void setDoors(int value) {
            doors = value;
        }
        void setRegistration(std::string value) {
            registration = value;
        }
        void setColor(std::string value) {
            color = value;
        }
        // getters
        int getWheels(void) {
            return wheels;
        }
        int getDoors(void) {
            return doors;
        }
        std::string getRegistration(void) {
            return registration;
        }
        std::string getColor(void) {
            return color;
        }

        // constructor
        Vehicle() {
            // initialize variables
            setWheels(0);
            setDoors(0);
            setRegistration("");
            setColor("Black");

        }

        // descructor
        ~Vehicle() {

        }

        void info() {
            std::cout << "Vehicle Info: Wheels = " << wheels << ", Doors = " << doors <<
              ", Color = " << color << ", Registration = " << registration << std::endl;
        }

        void start() {
            std::cout << "Engine Started" << std::endl;
        }

        void stop() {
           std::cout << "Engine Stopped" << std::endl;
        }
};

class Car : public Vehicle {
    public:
    // constructor
    Car() {
        setWheels(4);
        setDoors(4);
    }

    void drive() {
        std::cout << "Driving car" << std::endl;
    }

};

class Bike : public Vehicle {
    public:
    // constructor
    Bike() {
        setWheels(2);
        setDoors(0);
    }

    void ride() {
        std::cout << "Riding bike" << std::endl;
    }
};

class Plane : public Vehicle {
    public:
    // constructor
    Plane() {
        setWheels(6);
        setDoors(6);
    }

    void fly() {
        std::cout << "Flying plane" << std::endl;
    }

    // overloading stop function
    void stop() {
        std::cout << "Plane landing" << std::endl;
        std::cout << "Wheels out" << std::endl;
        std::cout << "Engine Stopped" << std::endl;
    }

};

// update values from common base class
void activateVehicle(Vehicle * vehicle, std::string color, std::string rego) {
    vehicle->setColor(color);
    vehicle->setRegistration(rego);
    vehicle->info();
    vehicle->start();
}

int main(void) {

    // Instantiate a new Car object
    std::cout << "Car" << std::endl;
 
    Car *car = new Car;
    activateVehicle(car, "Blue", "BH10GT");
    car->drive();
    car->stop();
    delete car;
 
    // Instantiate a new Bike object
    std::cout << "Bike" << std::endl;
 
    Bike *bike = new Bike;
    activateVehicle(bike, "Silver", "JK77TR");
    bike->ride();
    bike->stop();
    delete bike;
 
    // Instantiate a new Plane object
    std::cout << "Plane" << std::endl;
 
    Plane *plane = new Plane;
    activateVehicle(plane, "White", "FOX808");
    plane->fly();
    plane->stop();
    delete plane;
 

    return 0;
}

